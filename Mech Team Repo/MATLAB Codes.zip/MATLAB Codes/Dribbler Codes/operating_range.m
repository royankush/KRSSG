%% Motor Characteristics

% Stall Torque (in N-m)
Ts = 0.0755;         
% Stall Current (in A)
Is = 29.8;
% Free Speed (in rpm)
wf = 44500;
% Free Current
If = 0.397;
% Output Torque
T = linspace(0, Ts, 100);
v = 12;

%% Other parameters
% Gear Ratio 
GR = 18/5;
% Acceleration
a = linspace(-3,3,1000);
% Coefficient of friction between ball and ground
u1 = 0.66;
% Angle of dribbler
x = 0.26;
% Radius of the ball
R = 0.0215;
%Radius of Dribbler
Rb = 0.008;
% Mass of the ball
m = 0.046;
% Gravity
g = 9.81;

%% Finding torque 
% Normal force between ball and ground
N1 = (m*a*sin(x) + m*g*cos(x))/(((1-u1*cos(x))*cos(x)) - ((1+sin(x))*sin(x))*u1);
% Frictional force between ball and ground(max)
f1 = N1*u1;
% Required load torque
TL = f1*Rb;
% Output Torque of motor
Tmot = TL/GR;
% Current drawn
Idr = (Is - If)*(Tmot/Ts) + If;
% Efficiency at the point
nmot = 0.7;
% RPM of motor
wmot = nmot*((-wf)*(Tmot/Ts) + wf);
% RPM of dribbler
wdrib = wmot/GR;

figure
plot (a, wdrib);
xlabel('Acceleration');
ylabel('angular velocity of dribbler');
