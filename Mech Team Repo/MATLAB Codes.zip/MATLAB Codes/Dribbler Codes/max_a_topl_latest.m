%Mass of the bot and the ball respectively(in kg)
M= 3 ;
m= 0.046;
%Acceleration due to gravity(in m/s2)
g= 9.8;
%Coefficient of friction between ball and the ground
u1= 0.66;
u2= 0.9;
%%Dimensional Variables
x= linspace(0.25,0.27,1000);
rd= 14*(10^(-3));
b= (28.42 + rd*cos(x))*(10^(-3));
c= 98.38*(10^(-3));
d= 45*(10^(-3));
R= 21.5*(10^(-3));
%%Acceleration
a= linspace(-5, 5, 1000);

%% Calculation of Normal force between surface and ball(N1), ball and the dribbler bar(N2), between front wheels 
%% and the ground and u2N2- u1N1 (P)
for i=1:1000
    N1(i,:) = (m*a(i)*sin(x) + m*g*cos(x))./(((1-u1*cos(x)).*cos(x)) - ((1+sin(x)).*sin(x))*u1);
    N2(i,:) =  (m*a(i)*(1-u1*cos(x)) + u1*m*g*(1+sin(x)))./(((1-u1*cos(x)).*cos(x)) - ((1+sin(x)).*sin(x))*u1);
    Nf(i,:) = ( M*g*(c-d) - (N1(i,:)-m*g).*(b+c) - ((m*a(i)+u1*N1(i,:)).*(1+sin(x)))*R)/c;
    P(i,:) = u2*N2(i,:) - u1*N1(i,:);
end

%% Making the normal forces and P nan where it doen't satisfy:
%% N2>= 0; Nf>=0; u2N2-u1N1>=0
N2_temp = N2;
N1_temp = N1;
P_temp = P;
Nf_temp= Nf;

% angular accleration is taken to be 5000 rpm for bot velocity of 10m/s in backward direction...a
%     and so with motor of 30W no load rating and assuming 25 w to be dissipated at slipping in ground interface we evaluate that N1 < 4N

for i=1:1000
    for j=1:1000
        if( (N2_temp(i,j) < 0) | (P_temp(i,j) < 0) | (Nf(i,j) < 0) | (N1_temp(i,j) < 0) | (N1_temp(i,j) > 4) ) 
            N2_temp(i,j) = nan;
            N1_temp(i,j) = nan;
            P_temp(i,j) = nan;
            Nf_temp(i,j) = nan;
        end
    end
end

[xx aa] = meshgrid(x, a);
figure
surf(xx, aa, N2);
shading interp;
colorbar;
xlabel('Angle');
ylabel('Acceleration');
zlabel('u2N2- u1N1');

figure
surf(xx, aa, Nf_temp);
shading interp;
colorbar;
xlabel('Angle');
ylabel('Acceleration');
zlabel('Normal Force');
            
figure
surf(xx, aa, N1_temp);
shading interp;
colorbar;
xlabel('Angle');
ylabel('Acceleration');
zlabel('N1');
            
        


