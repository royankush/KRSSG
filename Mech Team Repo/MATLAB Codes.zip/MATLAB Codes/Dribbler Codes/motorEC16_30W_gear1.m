%% Motor Characteristics

% Stall Torque (in N-m)
Ts = 0.0755;         
% Stall Current (in A)
Is = 29.8;
% Free Speed (in rpm)
wf = 44500;
% Free Current
If = 0.397;
% Output Torque
T = linspace(0, Ts, 100);
%Operating Voltage
v = 12;

% Current Drawn
I = (Is - If)*(T/Ts) + If;
% Output Speed
w = (-wf)*(T/Ts) + wf;
% Power
P = (pi*T.*w)/30;
% Efficiency
n = P./(I*v);

%% Motor Nominal characteristics
% Nominal current
IN = 3.41;
% Nominal torque
TN = 0.00785;
% Safety factor;
sf = 0.7;
% Max current
IM = IN*sf;
% Max Torque;
TM = TN*sf;

%% Motor Curves
figure
plot(T, I);
figure
plot(T, w);
figure
plot(T, P);
figure
plot(T, n);

%% Robot requirements

% Normal force between ball and ground(max) 
N1 = 3.8;
% Coefficient of friction between ball and ground
u1 = 0.66;
% Frictional force between ball and ground(max)
f1 = N1*u1;
% Radius of the ball
R = 0.0215;
%Radius of Dribbler
Rb = 0.008;
% Required load torque
TL = f1*Rb;

%% Calculating Required Gear Ratio
GRf = TL/TM;
%GR = floor(TL/TM);
GR = 18/5;
% Output Torque of motor
Tmot = TL/GR;
% Current drawn
Idr = (Is - If)*(Tmot/Ts) + If;
% Efficiency at the point
nmot = 0.7;
% RPM of motor
wmot = nmot*((-wf)*(Tmot/Ts) + wf);
% RPM of dribbler
wdrib = wmot/GR;
%% Matching efficiency
%RPM of motor
wmot1 = (-wf)*(Tmot/Ts) + wf; 
% Power
Pmot1 = (pi*Tmot*wmot1)/30;
% Efficiency
nmot1 = Pmot1/(Idr*v);

