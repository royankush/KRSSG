clear all

m=3;
a=2;
g=9.81;
mu=linspace(0.1,0.9,100);
th1=10*pi./180;
th2=20*pi./180;
th3=30*pi./180;
th4=40*pi./180;
th5=50*pi./180;
th6=60*pi./180;
th7=70*pi./180;
th8=80*pi./180;
th9=90*pi./180;

N2N1=((m.*a.*(1-mu.*cos(th1)))+((1+sin(th1)).*mu.*g));
N2N2=((m.*a.*(1-mu.*cos(th2)))+((1+sin(th2)).*mu.*g));
N2N3=((m.*a.*(1-mu.*cos(th3)))+((1+sin(th3)).*mu.*g));
N2N4=((m.*a.*(1-mu.*cos(th4)))+((1+sin(th4)).*mu.*g));
N2N5=((m.*a.*(1-mu.*cos(th5)))+((1+sin(th5)).*mu.*g));
N2N6=((m.*a.*(1-mu.*cos(th6)))+((1+sin(th6)).*mu.*g));
N2N7=((m.*a.*(1-mu.*cos(th7)))+((1+sin(th7)).*mu.*g));
N2N8=((m.*a.*(1-mu.*cos(th8)))+((1+sin(th8)).*mu.*g));
N2N9=((m.*a.*(1-mu.*cos(th9)))+((1+sin(th9)).*mu.*g));

N2D1=(1-mu.*cos(th1).*cos(th1))-((1+sin(th1)).*mu.*sin(th1));
N2D2=(1-mu.*cos(th2).*cos(th2))-((1+sin(th2)).*mu.*sin(th2));
N2D3=(1-mu.*cos(th3).*cos(th3))-((1+sin(th3)).*mu.*sin(th3));
N2D4=(1-mu.*cos(th4).*cos(th4))-((1+sin(th4)).*mu.*sin(th4));
N2D5=(1-mu.*cos(th5).*cos(th5))-((1+sin(th5)).*mu.*sin(th5));
N2D6=(1-mu.*cos(th6).*cos(th6))-((1+sin(th6)).*mu.*sin(th6));
N2D7=(1-mu.*cos(th7).*cos(th7))-((1+sin(th7)).*mu.*sin(th7));
N2D8=(1-mu.*cos(th8).*cos(th8))-((1+sin(th8)).*mu.*sin(th8));
N2D9=(1-mu.*cos(th9).*cos(th9))-((1+sin(th9)).*mu.*sin(th9));

N21=N2N1./N2D1;
N22=N2N2./N2D2;
N23=N2N3./N2D3;
N24=N2N4./N2D4;
N25=N2N5./N2D5;
N26=N2N6./N2D6;
N27=N2N7./N2D7;
N28=N2N8./N2D8;
N29=N2N9./N2D9;

%plot(mu,N2)
%figure
%plot(mu,N2D)
%figure

figure
semilogy(mu,N21);hold on;
semilogy(mu,N22);hold on;
semilogy(mu,N23);hold on;
semilogy(mu,N24);hold on;
semilogy(mu,N25);hold on;
semilogy(mu,N26);hold on;
semilogy(mu,N27);hold on;
semilogy(mu,N28);hold on;
semilogy(mu,N29);
