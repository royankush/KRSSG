breadth=0.041;
length=0.054;
N_1=0;
for W=0.001:0.0001:0.0079                                                                                                                                                                      
q=0;
K=length*q;
%K is depth of plane ;
    i=1;
    t=0.0010;
    %i=current;
%A(height(outer))=0.018;
%B(length(outer))=0.041;
%d(diameter of wire)=0.00057;
O=0;
    for n=-K/0.00057:1:(length-K)/0.00057
        Z=n*0.00057;
        for w=0.00057:0.00057*(sqrt(3)/2):W
            x=breadth-2*W+2*w;
            y=0.018-2*W+2*w;
            for m=W+t+((0.018-2*W-2*t)/200):(0.018-2*W-2*t)/100:0.018-W-t-((0.018-2*W-2*t)/200)
                for l=W+t+((breadth-2*W-2*t)/200):(breadth-2*W-2*t)/100:breadth-W-t-((breadth-2*W-2*t)/200)
                    M=m;
                    L=l;
                    magnetic_field_1=1e-07*i*M*((1/sqrt(L*L+M*M+Z*Z))+(1/sqrt((x-L)*(x-L)+M*M+Z*Z)))*(1/sqrt(M*M+Z*Z));
                    magnetic_field_2=1e-07*i*L*((1/sqrt(L*L+M*M+Z*Z))+(1/sqrt(L*L+(y-M)*(y-M)+Z*Z)))*(1/sqrt(L*L+Z*Z));
                    magnetic_field=2*(magnetic_field_1+magnetic_field_2);
                    %flux due to two wires are taken flux due to other two
                    %is same;
                    O=O+magnetic_field*((0.018-2*W-2*t)/100)*((breadth-2*W-2*t)/100);
                end
            end
        end
    end
    N_1=N_1+1;
F(N_1,1)=O;
end
plot(F);

               
                

