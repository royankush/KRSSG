[num,txt,raw]=xlsread('C:\IIT\KRSSG\HUMANOID\my analysis files\gait data.xlsx');
f=217;
t=217;
m=80;
for i=1:12
    rhf=num(i,3);
    rkf=num(i,5);
    raf=num(i,6);
    x2=f*sin(rhf);y2=f*cos(rhf);
    x3=x2+t*sin(rhf-rkf);y3=y2+t*cos(rhf-rkf);
    x4=x3-m*sin(pi/2-raf+rhf-rkf);y4=y3+m*cos(pi/2-raf+rhf-rkf);
    X2(i)=x2;Y2(i)=y2;
    X3(i)=x3;Y3(i)=y3;
    X4(i)=x4;Y4(i)=y4;
end
for j=1:12
    cla;
    hold on;
    plot(X3,-Y3,'r*',X4,-y4,'g*',X3,-Y3,'r--',X4,-Y4,'g--');
    plot(X2,-Y2,'b*',X2,-Y2,'b--',0,0,'yx');
    plot(X3,-Y3,'bo',X4,-Y4,'bo',X2,-Y2,'bo');
    leg(1,1)=0;leg(1,2)=0;
    leg(2,1)=X2(j);leg(2,2)=-Y2(j);
    leg(3,1)=X3(j);leg(3,2)=-Y3(j);
    leg(4,1)=X4(j);leg(4,2)=-Y4(j);
    plot(leg(1:4,1),leg(1:4,2),'k-','LineWidth',3);
    if(j==1)
        pause(3);
    end
    pause(0.5);
end
clearvars leg;